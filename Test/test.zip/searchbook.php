<!DOCTYPE html>
<html>
    <head>
        <title>Login Form</title>
    </head>
    <body>
        <?php

            $bookName = "";
            $bookNameerr = "";
            $loginfail = "";

            if($_SERVER['REQUEST_METHOD'] == "POST" && $_REQUEST['button'] == "Search") {

                $mydata=file_get_contents("Book.txt");
            $data=json_decode($mydata);
            $s= count($data);





             


            for($i = 0; $i< $s; $i++) {
                

                if($data[$i]->bookName == $_POST['bName']) 
                {

                     
                   echo "Book Id :" .$data[$i]->bid; 
                   

              echo ",   Book Name :" .$data[$i]->bookName; 
                  

                     echo",   Book Author :". $data[$i]->bauthor; 
                     

                      echo ",   Book Publisher : " .$data[$i]->bpublisher; 
                     

                       echo",   Book Price :". $data[$i]->bprice;
                       




          

                    
                }
            }

            
            }
        ?>
        
        <h1>Welcome to Digital E-Book</h1>
        <form  action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST">

            <fieldset>
                <legend><b>Search Book</b></legend>
            
                <label for="bookName">Book Id:</label>
                <input type="text" name="bName" id="bookName">
                <?php echo $bookNameerr; ?>

                
                <br>

               

               
                
                </fieldset>

                <?php echo $loginfail; ?>

                <br>







                
            <input type="submit" value="Search" name="button"> 




            <h5>Back to the <a href="profile.php">profile</a></h5>  
        </form>

        <br>

       